const audio = document.getElementById("audio");
const title = document.getElementById("title");
const artist = document.getElementById("artist"); // Now correctly linked
const playBtn = document.getElementById("play"); // Main play/pause button
const playOverlayIcon = document.getElementById("play-overlay-icon"); // Overlay icon
const progress = document.getElementById("progress");
const currentTimeEl = document.getElementById("currentTime");
const durationEl = document.getElementById("duration"); // CORRECTED: Was document("duration")
const playlistEl = document.getElementById("playlist");
const cover = document.getElementById("cover");
const volumeControl = document.getElementById("volume");
const shuffleBtn = document.getElementById("shuffleBtn");
const repeatBtn = document.getElementById("repeatBtn");
const searchInput = document.getElementById("searchInput");
const playerCard = document.querySelector('.player-card'); // Get player card for playing/paused state
const coverArtWrapper = document.querySelector('.cover-art-wrapper'); // New: Get the wrapper for animation

let isPlaying = false;
let currentSongIndex = 0;
let isShuffled = false;
let isRepeating = 0; // 0: no repeat, 1: repeat all, 2: repeat one
let shuffledSongs = []; // To store shuffled order

// --- Music Data (Updated with 'artist' property) ---
const allSongs = [
    { title: "kan kan me hari", src: "songs/music1.mp3", artist: "Jaya Kishori", cover: "covers/hari.jpeg" },
    { title: "Burds volume", src: "songs/music2.mp3", artist: "Bird Sounds", cover: "covers/Burds.jpeg" },
    { title: "Tere mere hoto pe", src: "songs/music3.mp3", artist: "Lata Mangeshkar, Kishore Kumar", cover: "covers/hotope.jpeg" },
    { title: "Sang rani", src: "songs/sang rani.mp3", artist: "Adarsh Shinde", cover: "covers/sangrani.jpeg" },
    { title: "Sauda khara", src: "songs/sauda khara.mp3", artist: "Diljit Dosanjh, Sukhbir, Dhvani Bhanushali", cover: "covers/saudakhara.jpeg" },
    
];

let currentDisplayList = [...allSongs]; // This is the list currently shown in the UI (filtered or not)
let currentPlayableList = [...allSongs]; // This is the list the player is actually drawing from (shuffled or not, but full original if not shuffled)

// --- Core Player Functions ---

function loadSong(song) {
    if (!song) {
        title.textContent = "No Song";
        artist.textContent = "Please check your search or playlist.";
        cover.src = "covers/default.jpeg";
        audio.src = "";
        progress.style.width = "0%";
        currentTimeEl.textContent = "0:00";
        durationEl.textContent = "0:00";
        pauseSong();
        return;
    }
    title.textContent = song.title;
    artist.textContent = song.artist;
    audio.src = song.src;
    cover.src = song.cover || "covers/default.jpeg";
    highlightActiveSong();
}

function playSong() {
    isPlaying = true;
    playerCard.classList.remove('paused');
    playerCard.classList.add('playing');
    playBtn.innerHTML = '<i class="fas fa-pause"></i>';
    playOverlayIcon.classList.remove('fa-play');
    playOverlayIcon.classList.add('fa-pause');
    coverArtWrapper.classList.add('floating');
    audio.play();
}

function pauseSong() {
    isPlaying = false;
    playerCard.classList.remove('playing');
    playerCard.classList.add('paused');
    playBtn.innerHTML = '<i class="fas fa-play"></i>';
    playOverlayIcon.classList.remove('fa-pause');
    playOverlayIcon.classList.add('fa-play');
    coverArtWrapper.classList.remove('floating');
    audio.pause();
}

function togglePlayPause() {
    if (currentPlayableList.length === 0 || !audio.src) {
        return; // Prevents playing if no song is loaded
    }
    if (isPlaying) {
        pauseSong();
    } else {
        playSong();
    }
}

function nextSong() {
    if (currentPlayableList.length === 0) return;

    currentSongIndex++;
    if (currentSongIndex >= currentPlayableList.length) {
        currentSongIndex = 0; // Loop playlist
    }
    loadSong(currentPlayableList[currentSongIndex]);
    playSong();
}

function prevSong() {
    if (currentPlayableList.length === 0) return;

    currentSongIndex--;
    if (currentSongIndex < 0) {
        currentSongIndex = currentPlayableList.length - 1; // Loop playlist
    }
    loadSong(currentPlayableList[currentSongIndex]);
    playSong();
}

// --- Progress and Time Functions ---

function updateProgress() {
    if (audio.duration) {
        const percent = (audio.currentTime / audio.duration) * 100;
        progress.style.width = `${percent}%`;
        currentTimeEl.textContent = formatTime(audio.currentTime);
        durationEl.textContent = formatTime(audio.duration);
    }
}

function setProgress(e) {
    const width = e.currentTarget.clientWidth;
    const clickX = e.offsetX;
    const duration = audio.duration;
    if (!isNaN(duration) && duration > 0) {
        audio.currentTime = (clickX / width) * duration;
    }
}

function setVolume(value) {
    audio.volume = value;
}

function formatTime(sec) {
    const m = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return `${m}:${s < 10 ? "0" : ""}${s}`;
}

// --- Playlist Management ---

function populatePlaylist(songsToDisplay) {
    playlistEl.innerHTML = "";

    if (songsToDisplay.length === 0) {
        const li = document.createElement("li");
        li.classList.add("playlist-item", "no-results");
        li.textContent = "No songs found for your search.";
        playlistEl.appendChild(li);
        return;
    }

    songsToDisplay.forEach((song) => {
        const li = document.createElement("li");
        li.classList.add("playlist-item");
        li.dataset.originalSrc = song.src;
        li.innerHTML = `
            <span>${song.title}</span>
            <span class="artist-name">${song.artist}</span>
        `;
        li.onclick = () => {
            const clickedSongSrc = song.src;
            const targetIndex = currentPlayableList.findIndex(s => s.src === clickedSongSrc);
            
            if (targetIndex !== -1) {
                currentSongIndex = targetIndex;
                loadSong(currentPlayableList[currentSongIndex]);
                playSong();
            }
        };
        playlistEl.appendChild(li);
    });
    highlightActiveSong();
}

function highlightActiveSong() {
    const playlistItems = document.querySelectorAll('.playlist-item');
    playlistItems.forEach(item => item.classList.remove('active'));

    if (currentPlayableList.length === 0 || !currentPlayableList[currentSongIndex]) {
        return;
    }

    const activeSongSrc = currentPlayableList[currentSongIndex].src;
    const activeItem = Array.from(playlistItems).find(item => item.dataset.originalSrc === activeSongSrc);

    if (activeItem) {
        activeItem.classList.add('active');
        setTimeout(() => {
            activeItem.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }, 100);
    }
}

// --- Shuffle and Repeat ---

function shuffleArray(array) {
    const newArray = [...array];
    for (let i = newArray.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
    }
    return newArray;
}

function toggleShuffle() {
    isShuffled = !isShuffled;
    shuffleBtn.classList.toggle('active', isShuffled);

    const baseList = searchInput.value ? allSongs.filter(song =>
        song.title.toLowerCase().includes(searchInput.value.toLowerCase()) ||
        song.artist.toLowerCase().includes(searchInput.value.toLowerCase())
    ) : [...allSongs];

    if (isShuffled) {
        shuffledSongs = shuffleArray(baseList);
        currentPlayableList = shuffledSongs;
    } else {
        currentPlayableList = baseList;
    }

    const currentlyPlayingSong = audio.src ? allSongs.find(s => s.src === audio.src) : null;
    if (currentlyPlayingSong) {
        const newIndex = currentPlayableList.findIndex(s => s.src === currentlyPlayingSong.src);
        if (newIndex !== -1) {
            currentSongIndex = newIndex;
        } else {
            currentSongIndex = 0;
            if (currentPlayableList.length > 0) {
                loadSong(currentPlayableList[currentSongIndex]);
            } else {
                loadSong(null);
            }
        }
    } else if (currentPlayableList.length > 0) {
        currentSongIndex = 0;
        loadSong(currentPlayableList[currentSongIndex]);
    } else {
        loadSong(null);
    }

    if (searchInput.value.trim() !== "" || isShuffled) {
        populatePlaylist(currentPlayableList);
    } else {
        populatePlaylist(currentPlayableList.slice(0, 1));
    }

    if (isPlaying && currentPlayableList.length > 0) {
        playSong();
    } else {
        pauseSong();
    }
}

function toggleRepeat() {
    isRepeating = (isRepeating + 1) % 3; // Cycle: 0 (off), 1 (repeat all), 2 (repeat one)

    repeatBtn.classList.remove('active', 'active-one');
    if (isRepeating === 1) {
        repeatBtn.classList.add('active');
        repeatBtn.innerHTML = '<i class="fas fa-redo"></i>'; // Repeat all icon
        repeatBtn.title = 'Repeat All';
    } else if (isRepeating === 2) {
        repeatBtn.classList.add('active', 'active-one');
        repeatBtn.innerHTML = '<i class="fas fa-redo-alt"></i>'; // Repeat one icon
        repeatBtn.title = 'Repeat One';
    } else {
        repeatBtn.innerHTML = '<i class="fas fa-redo"></i>'; // Default icon
        repeatBtn.title = 'Repeat Off';
    }
}

// --- Search/Filter Functionality ---

function filterPlaylist() {
    const searchTerm = searchInput.value.toLowerCase().trim();

    const filteredSongs = allSongs.filter(song =>
        (song.title && song.title.toLowerCase().includes(searchTerm)) ||
        (song.artist && song.artist.toLowerCase().includes(searchTerm))
    );

    if (isShuffled) {
        currentPlayableList = shuffleArray(filteredSongs);
        shuffledSongs = [...currentPlayableList];
    } else {
        currentPlayableList = filteredSongs;
    }
    
    if (searchTerm === "") {
        currentDisplayList = currentPlayableList.slice(0, 1);
    } else {
        currentDisplayList = currentPlayableList;
    }

    populatePlaylist(currentDisplayList);

    const currentlyPlayingSong = audio.src ? allSongs.find(s => s.src === audio.src) : null;
    let newIndexForPlayingSong = -1;
    if (currentlyPlayingSong) {
        newIndexForPlayingSong = currentPlayableList.findIndex(s => s.src === currentlyPlayingSong.src);
    }

    if (newIndexForPlayingSong !== -1) {
        currentSongIndex = newIndexForPlayingSong;
        highlightActiveSong();
    } else {
        if (currentPlayableList.length > 0) {
            currentSongIndex = 0;
            loadSong(currentPlayableList[currentSongIndex]);
            pauseSong();
        } else {
            currentSongIndex = 0;
            loadSong(null);
        }
    }
}

// --- Event Listeners ---

audio.addEventListener("timeupdate", updateProgress);
audio.addEventListener("ended", () => {
    if (isRepeating === 2) {
        loadSong(currentPlayableList[currentSongIndex]);
        playSong();
    } else if (isRepeating === 1) {
        nextSong();
    } else if (isRepeating === 0 && currentSongIndex === currentPlayableList.length - 1) {
        pauseSong();
        currentSongIndex = 0;
        loadSong(currentPlayableList[currentSongIndex]);
    } else {
        nextSong();
    }
});

volumeControl.value = audio.volume;
volumeControl.addEventListener('input', (e) => {
    audio.volume = e.target.value;
});

// Event listeners for player controls
playBtn.addEventListener('click', togglePlayPause); // Main play/pause button
playOverlayIcon.parentElement.addEventListener('click', togglePlayPause); // Cover art overlay click
document.getElementById('next').addEventListener('click', nextSong);
document.getElementById('prev').addEventListener('click', prevSong);
progress.parentElement.addEventListener('click', setProgress); // Click on progress bar container

shuffleBtn.addEventListener('click', toggleShuffle);
repeatBtn.addEventListener('click', toggleRepeat);

// Search input event listener
searchInput.addEventListener('input', filterPlaylist);


// Initial load
document.addEventListener("DOMContentLoaded", () => {
    audio.volume = volumeControl.value;

    if (allSongs.length > 0) {
        currentPlayableList = [...allSongs];
        currentSongIndex = 0;
        loadSong(currentPlayableList[currentSongIndex]);
        populatePlaylist(allSongs.slice(0, 1)); // Show only the first song initially
    } else {
        title.textContent = "No Songs Available";
        artist.textContent = "Add music files to the 'songs' folder!";
        cover.src = "covers/default.jpeg";
        populatePlaylist([]);
    }
    
    playerCard.classList.add('paused'); // Initial state is paused
});