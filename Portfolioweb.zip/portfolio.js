// === Animate On Scroll Initialization ===
AOS.init({
    duration: 1000, // Animation duration
    once: true,     // Whether animation should happen only once - default
    offset: 100     // Offset (in px) from the top of the screen to trigger animations
});

// === Typewriter Effect ===
const typewriterText = document.querySelector('.typewriter');
const phrases = ["Frontend Developer", "UI/UX Designer", "Creative Thinker", "Problem Solver"]; // Added another phrase
let currentPhraseIndex = 0;
let currentCharIndex = 0;
let isDeleting = false;

function typeEffect() {
    if (!typewriterText) return; // Exit if element not found

    const current = phrases[currentPhraseIndex];
    typewriterText.textContent = isDeleting
        ? current.substring(0, currentCharIndex--)
        : current.substring(0, currentCharIndex++);

    let typingSpeed = isDeleting ? 50 : 100; // Faster deletion, slower typing

    if (!isDeleting && currentCharIndex === current.length) {
        // Pause at the end of typing
        typingSpeed = 1500; // Longer pause before deleting
        isDeleting = true;
    } else if (isDeleting && currentCharIndex === 0) {
        // Done deleting, move to next phrase
        isDeleting = false;
        currentPhraseIndex = (currentPhraseIndex + 1) % phrases.length;
        typingSpeed = 500; // Short pause before typing next phrase
    }

    setTimeout(typeEffect, typingSpeed);
}

// Start the typewriter effect after a short delay
window.addEventListener('load', () => {
    setTimeout(typeEffect, 500);
});


// === Smooth Scroll for Navigation Links ===
// Select all elements with the class 'nav-link'
document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', e => {
        e.preventDefault(); // Prevent default anchor link behavior

        // Get the target section's ID from the href attribute
        const targetId = link.getAttribute('href');
        const targetSection = document.querySelector(targetId);

        if (targetSection) {
            // Scroll to the target section smoothly
            targetSection.scrollIntoView({ behavior: 'smooth' });
        }
    });
});


// === Form Validation & Notification ===
const contactForm = document.querySelector('#contactForm');

// Function to show a temporary notification
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`; // Add 'success' or 'error' class
    notification.textContent = message;
    document.body.appendChild(notification);

    // Show the notification
    setTimeout(() => {
        notification.classList.add('show');
    }, 100); // Small delay to allow CSS transition

    // Hide and remove the notification after a few seconds
    setTimeout(() => {
        notification.classList.remove('show');
        notification.addEventListener('transitionend', () => {
            notification.remove();
        }, { once: true }); // Ensure listener is removed after one use
    }, 3000); // Notification visible for 3 seconds
}


contactForm?.addEventListener('submit', e => {
    e.preventDefault(); // Prevent actual form submission

    const nameInput = contactForm.querySelector('input[type="text"]');
    const emailInput = contactForm.querySelector('input[type="email"]');
    const messageTextarea = contactForm.querySelector('textarea');

    if (!nameInput.value || !emailInput.value || !messageTextarea.value) {
        showNotification("Please fill out all fields.", 'error');
    } else {
        // In a real application, you would send this data to a backend server
        // For demonstration, we'll just show a success message
        showNotification("Thank you for reaching out! Your message has been sent.", 'success');
        contactForm.reset(); // Clear the form fields
    }
});

// === Custom Cursor Effect ===
const cursor = document.querySelector('.cursor');
const follower = document.querySelector('.cursor-follower');

document.addEventListener('mousemove', e => {
    // Move cursor directly
    cursor.style.transform = `translate(${e.clientX}px, ${e.clientY}px)`;

    // Move follower with a slight delay/smoothness
    follower.style.transform = `translate(${e.clientX}px, ${e.clientY}px)`;
});


// Add hover effects for interactive elements
document.querySelectorAll('a, button, .logo, .theme-toggle, .social-icon, .skill-card, .project-card, .form-group input, .form-group textarea').forEach(el => {
    el.addEventListener('mouseenter', () => {
        cursor.style.transform = `translate(${event.clientX}px, ${event.clientY}px) scale(2)`;
        follower.style.transform = `translate(${event.clientX}px, ${event.clientY}px) scale(0)`;
        cursor.style.borderColor = 'transparent';
        cursor.style.backgroundColor = 'rgba(244, 63, 94, 0.4)'; /* Accent color for hover */
        cursor.style.mixBlendMode = 'normal'; /* Reset blend mode on hover for clear color */
    });
    el.addEventListener('mouseleave', () => {
        cursor.style.transform = `translate(${event.clientX}px, ${event.clientY}px) scale(1)`;
        follower.style.transform = `translate(${event.clientX}px, ${event.clientY}px) scale(1)`;
        cursor.style.borderColor = 'var(--accent-color)';
        cursor.style.backgroundColor = 'transparent';
        cursor.style.mixBlendMode = 'difference';
    });
});


// === Theme Toggle (Dark/Light Mode) ===
document.querySelector('.theme-toggle')?.addEventListener('click', () => {
    const root = document.documentElement;
    // Check current background-color to determine theme
    const isDark = getComputedStyle(root).getPropertyValue('--background-color').trim() === '#030712';
    const themeIcon = document.querySelector('.theme-toggle i');

    if (isDark) {
        // Switch to Light Mode
        root.style.setProperty('--background-color', '#ffffff');
        root.style.setProperty('--text-color', '#333333');
        root.style.setProperty('--glass-bg', 'rgba(0, 0, 0, 0.05)');
        root.style.setProperty('--glass-border', 'rgba(0, 0, 0, 0.15)');
        // Adjust gradients if needed for light mode, or keep them for contrast
        // For simplicity, keeping gradients as is.
        root.style.setProperty('--shadow', '0 8px 32px rgba(0, 0, 0, 0.1)');
        root.style.setProperty('--neon-shadow', '0 0 15px rgba(99, 102, 241, 0.5)'); // Slightly less intense for light mode

        if (themeIcon) {
            themeIcon.classList.remove('fa-moon');
            themeIcon.classList.add('fa-sun');
        }
        showNotification("Switched to Light Mode", 'success');

    } else {
        // Switch to Dark Mode
        root.style.setProperty('--background-color', '#030712');
        root.style.setProperty('--text-color', '#f8fafc');
        root.style.setProperty('--glass-bg', 'rgba(255, 255, 255, 0.03)');
        root.style.setProperty('--glass-border', 'rgba(255, 255, 255, 0.08)');
        root.style.setProperty('--shadow', '0 8px 32px rgba(0, 0, 0, 0.3)');
        root.style.setProperty('--neon-shadow', '0 0 15px var(--primary-color)');

        if (themeIcon) {
            themeIcon.classList.remove('fa-sun');
            themeIcon.classList.add('fa-moon');
        }
        showNotification("Switched to Dark Mode", 'success');
    }
});