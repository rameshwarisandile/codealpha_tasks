document.addEventListener('DOMContentLoaded', () => {
    const imageItems = document.querySelectorAll('.image-item');
    const lightbox = document.getElementById('lightbox');
    const lightboxImg = document.getElementById('lightbox-img');
    const lightboxCaption = document.getElementById('lightbox-caption'); // Still referenced, but not updated.
    const closeBtn = document.querySelector('.close-btn');
    const prevBtn = document.querySelector('.prev-btn');
    const nextBtn = document.querySelector('.next-btn');
    const lightboxImageWrapper = document.querySelector('.lightbox-image-wrapper');

    const themeToggleBtn = document.getElementById('theme-toggle');
    const body = document.body;

    const filterButtons = document.querySelectorAll('.filter-btn');
    const backToTopBtn = document.getElementById('back-to-top');

    let currentImageIndex = 0;
    let currentZoomLevel = 1;
    const maxZoomLevel = 3;
    const zoomStep = 0.5;

    let isDragging = false;
    let startX, startY;
    let imgOffsetX = 0, imgOffsetY = 0; // Current pan offsets

    // --- Theme Toggle Functionality ---
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
        body.classList.add(savedTheme);
    } else {
        body.classList.add('dark-theme'); // Default to dark theme for modern look
        localStorage.setItem('theme', 'dark-theme');
    }
    updateThemeToggleIcon();

    function updateThemeToggleIcon() {
        const icon = themeToggleBtn.querySelector('i');
        if (body.classList.contains('dark-theme')) {
            icon.classList.remove('fa-moon');
            icon.classList.add('fa-sun');
        } else {
            icon.classList.remove('fa-sun');
            icon.classList.add('fa-moon');
        }
    }

    themeToggleBtn.addEventListener('click', () => {
        if (body.classList.contains('dark-theme')) {
            body.classList.remove('dark-theme');
            body.classList.add('light-theme');
            localStorage.setItem('theme', 'light-theme');
        } else {
            body.classList.remove('light-theme');
            body.classList.add('dark-theme');
            localStorage.setItem('theme', 'dark-theme');
        }
        updateThemeToggleIcon();
    });

    // --- Filter Functionality (with Ripple Effect) ---
    filterButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            // Ripple effect
            const circle = document.createElement('span');
            const diameter = Math.max(this.clientWidth, this.clientHeight);
            const radius = diameter / 2;

            circle.style.width = circle.style.height = `${diameter}px`;
            // Ensure ripple position is relative to the button, not document
            circle.style.left = `${e.clientX - this.getBoundingClientRect().left - radius}px`;
            circle.style.top = `${e.clientY - this.getBoundingClientRect().top - radius}px`;
            circle.classList.add('ripple');

            const ripple = this.getElementsByClassName('ripple')[0];

            if (ripple) {
                ripple.remove();
            }

            this.appendChild(circle);

            // Filter logic
            filterButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active'); // Use 'this' as it refers to the clicked button

            const filter = this.dataset.filter;

            // Trigger reflow/re-render to ensure smooth hiding/showing
            // by adding a small delay or using next frame
            requestAnimationFrame(() => {
                imageItems.forEach(item => {
                    const category = item.dataset.category;
                    if (filter === 'all' || category === filter) {
                        item.classList.remove('hidden');
                    } else {
                        item.classList.add('hidden');
                    }
                });
            });
        });
    });

    // --- Lazy Loading Images ---
    const lazyImages = document.querySelectorAll('img.lazy');

    const lazyLoad = (entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.classList.remove('lazy');
                observer.unobserve(img);
            }
        });
    };

    const imageObserver = new IntersectionObserver(lazyLoad, {
        rootMargin: '0px 0px 150px 0px', // Load images a bit earlier
        threshold: 0.05 // Trigger when 5% of the image is visible
    });

    lazyImages.forEach(img => imageObserver.observe(img));


    // --- Lightbox & Image Navigation Functionality ---

    const applyTransform = () => {
        lightboxImg.style.transform = `scale(${currentZoomLevel}) translate(${imgOffsetX}px, ${imgOffsetY}px)`;
    };

    const resetZoomAndPan = () => {
        currentZoomLevel = 1;
        imgOffsetX = 0;
        imgOffsetY = 0;
        applyTransform();
        lightboxImageWrapper.classList.remove('zoom-active');
        lightboxImageWrapper.style.cursor = 'zoom-in';
    };

    const openLightbox = (index) => {
        currentImageIndex = index;
        const item = imageItems[currentImageIndex];
        // Ensure the image is loaded before showing in lightbox
        const imgSrc = item.querySelector('img').src || item.querySelector('img').dataset.src;
        
        lightboxImg.src = imgSrc;
        // Removed: lightboxCaption.textContent = imgCaption; // No longer updating the caption
        lightbox.style.display = 'flex';
        resetZoomAndPan();
        document.body.style.overflow = 'hidden'; // Prevent scrolling when lightbox is open
    };

    const closeLightbox = () => {
        lightbox.style.display = 'none';
        resetZoomAndPan();
        document.body.style.overflow = ''; // Restore scrolling
    };


    const showNextImage = () => {
        const visibleImageItems = Array.from(imageItems).filter(item => !item.classList.contains('hidden'));
        if (visibleImageItems.length === 0) return;

        let nextIndexInVisible = -1;
        for (let i = 0; i < visibleImageItems.length; i++) {
            if (visibleImageItems[i] === imageItems[currentImageIndex]) {
                nextIndexInVisible = (i + 1) % visibleImageItems.length;
                break;
            }
        }
        if (nextIndexInVisible !== -1) {
            const nextImageElement = visibleImageItems[nextIndexInVisible];
            currentImageIndex = Array.from(imageItems).indexOf(nextImageElement);
            openLightbox(currentImageIndex);
        }
    };

    const showPrevImage = () => {
        const visibleImageItems = Array.from(imageItems).filter(item => !item.classList.contains('hidden'));
        if (visibleImageItems.length === 0) return;

        let prevIndexInVisible = -1;
        for (let i = 0; i < visibleImageItems.length; i++) {
            if (visibleImageItems[i] === imageItems[currentImageIndex]) {
                prevIndexInVisible = (i - 1 + visibleImageItems.length) % visibleImageItems.length;
                break;
            }
        }
        if (prevIndexInVisible !== -1) {
            const prevImageElement = visibleImageItems[prevIndexInVisible];
            currentImageIndex = Array.from(imageItems).indexOf(prevImageElement);
            openLightbox(currentImageIndex);
        }
    };

    // Event listeners for opening lightbox
    imageItems.forEach((item, index) => {
        item.addEventListener('click', () => {
            openLightbox(index);
        });
    });

    // Event listener for closing lightbox
    closeBtn.addEventListener('click', closeLightbox);

    // Event listeners for navigation buttons
    prevBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        showPrevImage();
    });

    nextBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        showNextImage();
    });

    // Close lightbox when clicking outside the image (on the dark background)
    lightbox.addEventListener('click', (e) => {
        if (e.target === lightbox) {
            closeLightbox();
        }
    });

    // --- Image Zoom & Pan Functionality ---
    lightboxImageWrapper.addEventListener('click', (e) => {
        if (e.target === lightboxImg || e.target === lightboxImageWrapper || e.target.closest('.zoom-overlay')) {
            if (currentZoomLevel === 1) {
                currentZoomLevel = 2;
                applyTransform();
                lightboxImageWrapper.classList.add('zoom-active');
                lightboxImageWrapper.style.cursor = 'grab';
            } else {
                resetZoomAndPan();
            }
        }
    });

    // Pan functionality
    lightboxImageWrapper.addEventListener('mousedown', (e) => {
        if (currentZoomLevel > 1 && (e.target === lightboxImg || e.target === lightboxImageWrapper)) {
            isDragging = true;
            startX = e.clientX - imgOffsetX;
            startY = e.clientY - imgOffsetY;
            lightboxImageWrapper.style.cursor = 'grabbing';
            e.preventDefault();
        }
    });

    lightboxImageWrapper.addEventListener('mousemove', (e) => {
        if (!isDragging) return;
        imgOffsetX = e.clientX - startX;
        imgOffsetY = e.clientY - startY;

        const wrapperRect = lightboxImageWrapper.getBoundingClientRect();
        const imgRect = lightboxImg.getBoundingClientRect();

        // Calculate maximum allowed offset based on current zoom and image/wrapper dimensions
        const maxOffsetX = (imgRect.width * currentZoomLevel - wrapperRect.width) / (2 * currentZoomLevel);
        const maxOffsetY = (imgRect.height * currentZoomLevel - wrapperRect.height) / (2 * currentZoomLevel);

        imgOffsetX = Math.max(-maxOffsetX, Math.min(maxOffsetX, imgOffsetX));
        imgOffsetY = Math.max(-maxOffsetY, Math.min(maxOffsetY, imgOffsetY));

        applyTransform();
    });

    lightboxImageWrapper.addEventListener('mouseup', () => {
        isDragging = false;
        if (currentZoomLevel > 1) {
            lightboxImageWrapper.style.cursor = 'grab';
        } else {
            lightboxImageWrapper.style.cursor = 'zoom-in';
        }
    });

    lightboxImageWrapper.addEventListener('mouseleave', () => {
        isDragging = false;
        if (currentZoomLevel > 1) {
            lightboxImageWrapper.style.cursor = 'grab';
        } else {
            lightboxImageWrapper.style.cursor = 'zoom-in';
        }
    });


    // Mouse wheel zoom
    lightboxImageWrapper.addEventListener('wheel', (e) => {
        if (lightbox.style.display === 'flex') {
            e.preventDefault();

            const oldZoomLevel = currentZoomLevel;

            if (e.deltaY < 0) {
                currentZoomLevel = Math.min(maxZoomLevel, currentZoomLevel + zoomStep);
            } else {
                currentZoomLevel = Math.max(1, currentZoomLevel - zoomStep);
            }

            const rect = lightboxImageWrapper.getBoundingClientRect();
            const mouseX = e.clientX - rect.left - rect.width / 2;
            const mouseY = e.clientY - rect.top - rect.height / 2;

            const zoomRatio = currentZoomLevel / oldZoomLevel;
            imgOffsetX = mouseX - (mouseX - imgOffsetX) * zoomRatio;
            imgOffsetY = mouseY - (mouseY - imgOffsetY) * zoomRatio;

            const imgRect = lightboxImg.getBoundingClientRect();
            const maxOffsetX = (imgRect.width * currentZoomLevel - rect.width) / (2 * currentZoomLevel);
            const maxOffsetY = (imgRect.height * currentZoomLevel - rect.height) / (2 * currentZoomLevel);
            imgOffsetX = Math.max(-maxOffsetX, Math.min(maxOffsetX, imgOffsetX));
            imgOffsetY = Math.max(-maxOffsetY, Math.min(maxOffsetY, imgOffsetY));


            applyTransform();

            if (currentZoomLevel > 1) {
                lightboxImageWrapper.classList.add('zoom-active');
                lightboxImageWrapper.style.cursor = 'grab';
            } else {
                resetZoomAndPan();
            }
        }
    }, { passive: false });

    // Close lightbox with Escape key and navigate with arrow keys
    document.addEventListener('keydown', (e) => {
        if (lightbox.style.display === 'flex') {
            if (e.key === 'Escape') {
                closeLightbox();
            } else if (e.key === 'ArrowRight') {
                showNextImage();
            } else if (e.key === 'ArrowLeft') {
                showPrevImage();
            }
        }
    });

    // --- Back to Top Button Functionality ---
    window.addEventListener('scroll', () => {
        if (window.scrollY > 300) {
            backToTopBtn.style.display = 'flex';
            backToTopBtn.style.opacity = '1';
        } else {
            backToTopBtn.style.opacity = '0';
            setTimeout(() => {
                if (window.scrollY <= 300) {
                    backToTopBtn.style.display = 'none';
                }
            }, 300);
        }
    });

    backToTopBtn.addEventListener('click', () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });

});